const { Resend } = require("resend");

module.exports = async function (req, res) {
  const resend = new Resend(req.variables.RESEND_API_KEY); // Use Resend API key from environment variables

  const { to, subject, body } = JSON.parse(req.payload);

  try {
    const response = await resend.emails.send({
      from: "no-reply@yourdomain.com", // Replace with your verified sender email
      to,
      subject,
      html: body, // Use HTML for the email body
    });

    console.log("Resend response:", response);
    res.json({ success: true, message: "Email sent successfully." });
  } catch (error) {
    console.error("Error sending email with Resend:", error);
    res.json({ success: false, message: "Failed to send email." });
  }
};
