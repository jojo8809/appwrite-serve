const { Resend } = require("resend");

module.exports = async function(req, res) {
  console.log("Function execution started...");
  console.log("Request object keys:", Object.keys(req));
  
  try {
    let payload;
    
    // Special handling for Appwrite console testing
    // The payload might be in req.body or directly in req when executing from console
    if (req.payload === undefined) {
      console.log("Payload is undefined, looking for alternatives");
      
      if (req.body) {
        console.log("Found req.body, trying to use that");
        payload = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      } else if (req.method === 'POST' && typeof req.rawBody === 'string') {
        console.log("Found req.rawBody, trying to use that");
        payload = JSON.parse(req.rawBody);
      } else {
        // Handle direct execution from Appwrite console
        // When executed directly, the data might be the request itself
        try {
          const reqString = JSON.stringify(req);
          const reqData = JSON.parse(reqString);
          
          console.log("Trying to extract payload from request object");
          
          // Find payload in different possible locations
          if (reqData.body) payload = reqData.body;
          else if (reqData.data) payload = reqData.data;
          else if (reqData.rawBody) payload = JSON.parse(reqData.rawBody);
          else if (reqData.to && reqData.subject && reqData.body) {
            // If req itself contains the email fields
            payload = {
              to: reqData.to,
              subject: reqData.subject,
              body: reqData.body,
              apiKey: reqData.apiKey
            };
          }
        } catch (e) {
          console.error("Error extracting payload from request:", e);
        }
      }
      
      // Last resort - check if we're testing from console with a hardcoded test payload
      if (!payload || Object.keys(payload).length === 0) {
        console.log("Using hardcoded test values for console testing");
        payload = {
          to: "iannazzi.joseph@gmail.com",
          subject: "Test Email from Console",
          body: "<p>This is a test email sent from the Appwrite console.</p>"
        };
      }
    } else {
      // Normal case - payload is available
      if (typeof req.payload === 'string') {
        try {
          payload = JSON.parse(req.payload);
        } catch (e) {
          console.error("Error parsing payload string:", e);
          payload = {};
        }
      } else if (typeof req.payload === 'object') {
        payload = req.payload;
      } else {
        console.log("Payload is not string or object:", typeof req.payload);
        payload = {};
      }
    }
    
    console.log("Final payload:", payload);
    
    const { to, subject, body, apiKey } = payload || {};
    
    // Use API key from payload if environment variable is not available
    const resendApiKey = (req.variables && req.variables.RESEND_API_KEY) || 
                         apiKey || 
                         "re_cKhSe1Ao_7Wyvkcfq6AjC8Ccorq4GeoQA"; // Fallback to hardcoded key
    
    console.log("Using API key:", resendApiKey ? "Key provided" : "No key available");
    
    if (!resendApiKey) {
      console.error("RESEND_API_KEY is missing.");
      return { success: false, message: "API key is missing." };
    }
    
    // Validate required fields
    if (!to || !subject || !body) {
      console.error("Missing required fields in payload.");
      console.log("To:", to);
      console.log("Subject:", subject);
      console.log("Body length:", body?.length || 0);
      return { success: false, message: "Missing required fields (to, subject, or body)." };
    }

    // Create Resend instance
    const resend = new Resend(resendApiKey);
    
    // Log the email request
    console.log("Sending email with the following details:", {
      from: "no-reply@justlegalsolutions.tech",
      to,
      subject,
      bodyLength: body.length
    });

    // Send the email
    const response = await resend.emails.send({
      from: "no-reply@justlegalsolutions.tech",
      to,
      subject,
      html: body,
    });

    // Log the response from Resend
    console.log("Resend API response:", response);

    return { success: true, message: "Email sent successfully.", response };
  } catch (error) {
    console.error("Error sending email with Resend:", error);
    return { success: false, message: "Failed to send email.", error: error.message };
  }
};
